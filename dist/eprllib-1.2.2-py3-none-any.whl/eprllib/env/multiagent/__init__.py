"""The multi-agent aproach allow to run multiples agents in the environment, but also
a single agent.
The standard configuration use a policy with fully shared parameters.

You can check the entire configuration of the multi-agent approach in the
`multiagent_config.py` file on ExampleFiles folder.
"""
