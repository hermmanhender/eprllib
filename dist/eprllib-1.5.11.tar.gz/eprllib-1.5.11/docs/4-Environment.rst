Environment API
================

Work in progres...

How work the standard environment in DRL
-----------------------------------------

Work in progres...

Implementation in RLlib.

Custom environment implemented in eprllib.

Using the callbackpoints of EnergyPlus Python API.
