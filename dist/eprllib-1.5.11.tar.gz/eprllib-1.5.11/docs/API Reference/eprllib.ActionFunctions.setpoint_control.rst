﻿eprllib.ActionFunctions.setpoint\_control
=========================================

.. automodule:: eprllib.ActionFunctions.setpoint_control

   
   .. rubric:: Classes

   .. autosummary::
   
      availability
      discrete_dual_setpoint_and_availability
   