﻿eprllib.ActionFunctions
=======================

.. automodule:: eprllib.ActionFunctions

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   ActionFunctions
   setpoint_control
   window_opening_control
   window_shading_control
