﻿eprllib.ObservationFunctions
============================

.. automodule:: eprllib.ObservationFunctions

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   ObservationFunctions
   centralized
   fully_shared_parameters
   independent
