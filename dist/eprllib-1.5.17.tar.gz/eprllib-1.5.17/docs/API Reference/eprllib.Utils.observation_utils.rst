eprllib.Utils.observation\_utils
================================

.. automodule:: eprllib.Utils.observation_utils

   
   .. rubric:: Functions

   .. autosummary::
   
      get_actuator_name
      get_internal_variable_name
      get_meter_name
      get_other_obs_name
      get_parameter_name
      get_parameter_prediction_name
      get_variable_name
   