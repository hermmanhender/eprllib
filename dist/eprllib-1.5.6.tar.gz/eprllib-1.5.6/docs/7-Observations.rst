Observations
=============

Work in progress...