﻿eprllib.ObservationFunctions
============================

.. automodule:: eprllib.ObservationFunctions

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   CentralizedAgent
   FullySharedParameters
   IndependentLearning
   ObservationFunctions
