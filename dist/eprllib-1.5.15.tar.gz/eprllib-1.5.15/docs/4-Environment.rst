Environment API
================

Work in progres...

.. image:: Images/env_config.png
    :width: 600


How work the standard environment in DRL
-----------------------------------------

Work in progres...

Implementation in RLlib.

Custom environment implemented in eprllib.

Using the callbackpoints of EnergyPlus Python API.
