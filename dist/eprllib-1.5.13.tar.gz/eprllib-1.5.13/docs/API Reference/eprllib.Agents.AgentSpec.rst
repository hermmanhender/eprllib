﻿eprllib.Agents.AgentSpec
========================

.. automodule:: eprllib.Agents.AgentSpec

   
   .. rubric:: Classes

   .. autosummary::
   
      ActionSpec
      AgentSpec
      FilterSpec
      ObservationSpec
      RewardSpec
      TriggerSpec
   