eprllib.ActionFunctions.window\_opening\_control
================================================

.. automodule:: eprllib.ActionFunctions.window_opening_control

   
   .. rubric:: Classes

   .. autosummary::
   
      discrete_opening
   