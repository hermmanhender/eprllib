eprllib.EpisodeFunctions.GeneralBuilding
========================================

.. automodule:: eprllib.EpisodeFunctions.GeneralBuilding

   
   .. rubric:: Classes

   .. autosummary::
   
      GeneralBuilding
   