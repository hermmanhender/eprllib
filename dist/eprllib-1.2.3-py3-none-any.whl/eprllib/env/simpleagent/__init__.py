"""This module is in development. You can use instead the multi-agent
env configuration with only one agent
"""