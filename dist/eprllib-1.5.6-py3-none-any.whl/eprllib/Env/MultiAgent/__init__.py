"""
Multi-Agent Environment
=======================

The multi-agent aproach allow to run multiples agents in the environment, but also
a single agent.

The standard configuration use a policy with fully shared parameters.

You can configure the environment with the :class:`~eprllib.Env.EnvConfig.EnvConfig` class .
"""
