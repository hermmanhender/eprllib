﻿eprllib.Agents.Triggers.SetpointTriggers
========================================

.. automodule:: eprllib.Agents.Triggers.SetpointTriggers

   
   .. rubric:: Classes

   .. autosummary::
   
      AvailabilityTrigger
      DualSetpointTriggerDiscreteAndAvailabilityTrigger
   