"""
Utilities
==========

Work in progress...
"""