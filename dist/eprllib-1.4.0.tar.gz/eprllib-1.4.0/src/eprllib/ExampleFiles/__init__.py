"""
Example files
=============

This module contains example files for the different file types supported by the
package.
"""
