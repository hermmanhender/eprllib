"""
Pre Process Functions
=====================

This module contains functions to preprocess the data before training or
inference. Some of these functions will be used in training, others will
be used in inference.
"""
