"""
Agents
======

This module contains classes for representing and manipulating agents in the
environment. The agents are responsible for taking actions in the environment
following a specified policy.
"""