eprllib.ActionFunctions.window\_shading\_control
================================================

.. automodule:: eprllib.ActionFunctions.window_shading_control

   
   .. rubric:: Classes

   .. autosummary::
   
      shading_actions
   