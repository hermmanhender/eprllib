"""This module contain all the methods to generate plots to postprocess the results of training.
"""
