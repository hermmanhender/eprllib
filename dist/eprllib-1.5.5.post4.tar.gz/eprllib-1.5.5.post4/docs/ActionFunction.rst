Action space and action functions
=================================

How is defined the action space in eprllib.

The meaning of implement a action funciton.

How is implemented the action function.
