Dinamic episode properties
==========================

The meaning of the episode functions.

How to customize a episode function.
