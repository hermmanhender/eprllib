eprllib.PostProcess.Evaluation
==============================

.. automodule:: eprllib.PostProcess.Evaluation

   
   .. rubric:: Classes

   .. autosummary::
   
      drl_evaluation
      step_processing
   