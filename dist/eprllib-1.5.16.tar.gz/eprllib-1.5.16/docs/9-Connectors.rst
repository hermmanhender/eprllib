AgentConnectors API
====================

Work in progres...

Introduction to reward functions in DRL.

Why to use infos in the reward function.

How to configurate a reward function.
