eprllib.Utils.annotations
=========================

.. automodule:: eprllib.Utils.annotations

   
   .. rubric:: Functions

   .. autosummary::
   
      override
   