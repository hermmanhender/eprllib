"""
Observation Functions
======================

Work in progress...
"""