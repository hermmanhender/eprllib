Dinamic episode properties
==========================

Work in progres...

The meaning of the episode functions.

How to customize a episode function.
