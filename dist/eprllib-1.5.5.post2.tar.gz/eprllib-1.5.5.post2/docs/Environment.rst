EnergyPlus as an Environment for DRL
====================================

How work the standard environment in DRL.

Implementation in RLlib.

Custom environment implemented in eprllib.

Using the callbackpoints of EnergyPlus Python API.
