eprllib.RewardFunctions.Nygard1990
==================================

.. automodule:: eprllib.RewardFunctions.Nygard1990

   
   .. rubric:: Classes

   .. autosummary::
   
      Nygard1990
   