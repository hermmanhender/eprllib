eprllib.Agents.AgentSpec
========================

.. automodule:: eprllib.Agents.AgentSpec

   
   .. rubric:: Classes

   .. autosummary::
   
      AgentSpec
   