﻿eprllib.Agents
==============

.. automodule:: eprllib.Agents

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   AgentSpec
   ConventionalAgent
   OnOffAirConditionerControl
   WindowOpeningControl
   WindowShadeControl
