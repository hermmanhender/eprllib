"""
Multiagent Functions
=====================


"""